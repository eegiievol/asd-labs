package bank.domain;

public interface addCalcInterest {
    public double calcInterest(double balance);
}
