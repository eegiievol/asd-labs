package counter;

public interface CounterObserver {
    public void update(int cnt);
}
